import java.util.Scanner;

public class HomeWork3A
{
    public static void main(String[] args) 
    {
        Scanner stdin = new Scanner(System.in);
        
        String start = "0";  
        System.out.print("Enter in scores:");
        System.out.print("Enter in -1 to terminate prorgam."); 
        while(!start.equals("1"))
        {      
         int scores = stdin.nextInt(); 
         
         if(scores==(-1))break; 
        }
         
       System.out.print("Enter in scores: "); 
       while(!start.equals("2")) 
       {
        int scores2 = stdin.nextInt(); 
        
        if(scores2==(-1))break; 
        }
       }
      } 
