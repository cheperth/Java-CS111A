//**************************************************
/* First.java  This program displays "In the twilight rain" 
   by Matsuo Basho */
// inputs : none
// outputs : message
// Written by   : Che Perth 
// Last Modified: September 8 2017
//**************************************************
public class Haiku 
{
 public static void main (String[] args)  
 {
  System.out.print("In the "); 
  System.out.print("twilight rain\n"); 
  System.out.print("these brilliant-hued hibiscus. . .\nA lovely sunset");   
 }
}




