public class PrintPatters.java  
 {
	public static void main(String[] args) 
	 {
		
      
      System.out.println(" ________");
		System.out.println("|  Che   |");
		System.out.println("+________+");
     

      System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
     
     
     

      System.out.println("********     *       *     ******** ");
		System.out.println("*            *       *     *        ");
		System.out.println("*            *       *     *        ");
		System.out.println("*            *********     ******** ");
		System.out.println("*            *       *     *        ");
		System.out.println("*            *       *     *        ");
		System.out.println("********     *       *     ******** ");
				

      System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");

     
               
               System.out.println (" iiiiiiiii ");
	            System.out.println (" ^^^^^^^^^ ");
	    System.out.println (" =       = ");
               System.out.println ("O|@     @|O");  
               System.out.println (" |   >   | ");
               System.out.println (" |  ___  | ");
               System.out.println (" |   =   | ");
               System.out.println (" +_______+ ");
	 
      System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");

       

      
       System.out.println("   /\\___/\\    _________  ");
        System.out.println("  ( *   * )  /  Coding \\ ");
        System.out.println("  (   >   ) <     is   |");
        System.out.println("  (  ___  )  \\   Fun!! / ");
        System.out.println("  |   _   |   +-------+ ");
        System.out.println("  |  | |  |             ");
        System.out.println(" _|  | |  |_            ");
        System.out.println("[____||_____]           ");
      
     }
  
 }
